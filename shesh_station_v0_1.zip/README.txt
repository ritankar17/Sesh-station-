SHESH STATION — Prototype v0.1

This is a visual/interaction prototype. It is deliberately not shipping copyrighted Bengali recordings.
Open index.html in a browser to try the interface.

Next development steps:
1. Replace the demo song layer with legitimate playback sources.
2. Add multiple era-specific background images.
3. Add real radio-static and ambience audio assets.
4. Add the historical-date engine and 12:00 AM–03:30 AM broadcast timeline.
5. Deploy on a free static host such as GitHub Pages.
